#!/bin/sh
nc localhost 12345