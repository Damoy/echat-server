#!/bin/sh
elixir ./chat.ex